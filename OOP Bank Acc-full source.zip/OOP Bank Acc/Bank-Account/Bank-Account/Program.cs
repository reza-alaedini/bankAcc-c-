﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bank_Account
{
    class Program
    {
        static void Main(string[] args)
        {
            Bank_Account Parsa = new Bank_Account("Parsa", "Alaei", 6037997310133513, 50000);

            Bank_Account Reza = new Bank_Account("Reza", "Alaedini", 5892101369742044, 100000);

            Bank_Account Mohammad = new Bank_Account("Mohammad", "Heidari", 9040227795164820, 20000);

            Console.WriteLine(Parsa); // Show Full Information About Account
            Console.WriteLine(Reza);
            Console.WriteLine(Mohammad);

            // Actions
            //Console.WriteLine(Parsa.withdraw(5000)); // Withdraw Action - without error
            //Console.WriteLine(Parsa.withdraw(60000)); // Withdraw Action -  with error


            //Console.WriteLine(Parsa.Deposit(Reza, 10000)); //Deposit Action - without error
            //Console.WriteLine(Parsa.Deposit(Reza, 90000)); //Deposit Action - with error
            

            Console.ReadKey();
        }

        class Bank_Account
        {
            public string name;
            public string lastname;
            private long accno;
            public long inventory;

            public long AccNo
            {
                get { return accno; }
                set {
                    double AccNoLength = Math.Floor(Math.Log10(value) + 1);

                    if (AccNoLength == 16)
                    {
                        accno = value;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("{0}'s Bank Account Number is Invalid!", name);
                        Console.ForegroundColor = ConsoleColor.White;
                        accno = 0;
                    }

                    
                }
            }

            public string Deposit(Bank_Account _name, long _amount)
            {
                if (inventory < _amount)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    return string.Format("Deposit Action Failed !\nBecause Requested Amount is More Than {0}'s Account Inventory !", name);
                }
                else
                {
                    long DResult = _name.inventory + _amount;
                    long DOResult = inventory - _amount;
                    _name.inventory = DResult;
                    inventory = DOResult;
                    Console.ForegroundColor = ConsoleColor.Green;
                    return string.Format("Deposit Action SUCCESSFULLY Done !\nNew {0}'s Account Inventory is : {1} T\nAnd New {2}'s Account Inventory is : {3} T\n----------", _name.name, DResult, name, DOResult);
                }
            }

            public string withdraw( long _amount)
            {
                if (inventory < _amount)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    return string.Format("Withdraw Action Failed!\n{0}'s Account Inventory is LESS THAN Your Request!", name);
                }
                else
                {
                    long result = inventory - _amount;
                    inventory = result;
                    Console.ForegroundColor = ConsoleColor.Green;
                    return string.Format("Withdraw Action SUCCESSFULLY Done !\nNew {0}'s Account Inventory : {1} T", name, result);                  
                }
            }

            public Bank_Account(string _name, string _lastname, long _accno, long _inventory)
            {
                name = _name;
                lastname = _lastname;
                AccNo = _accno;
                inventory = _inventory;
            }

            public override string ToString()
            {
                Console.ForegroundColor = ConsoleColor.White;
                return string.Format("Name: {0} , Last Name: {1} , Bank Account Number: {2} , Amount of Money: {3} T\n-------------", name, lastname, accno, inventory);
            }
            
        }

        
    }
}
